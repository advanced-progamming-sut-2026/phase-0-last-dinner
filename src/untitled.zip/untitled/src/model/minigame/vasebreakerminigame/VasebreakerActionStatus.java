package model.minigame.vasebreakerminigame;

public enum VasebreakerActionStatus {
    STARTED,

    VASE_BROKEN,

    SEED_PACKET_COLLECTED,

    PLANT_FROM_PACKET,

    TIME_ADVANCED,

    NO_VASE_AT_POSITION,

    NO_SEED_PACKET_AT_POSITION,

    SEED_PACKET_NOT_AVAILABLE,

    NO_COLLECTED_SEED_PACKET,

    INVALID_STAGE,

    STAGE_LOCKED,

    GAME_NOT_STARTED,

    GAME_ALREADY_FINISHED,

    INVALID_POSITION,

    TILE_OCCUPIED,

    TILE_HAS_UNBROKEN_VASE,

    INVALID_ACTION
}